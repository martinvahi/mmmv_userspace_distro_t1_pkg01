Why BOB?

Too many people use the Internet drunken. See the web, PHP and other
technologies, where this will end.

To show you how not to write code drunken and simplify things, this is an
example of how to add your own dynamic handler language to geomyidae.

We support that people should use gopherspace only when being sober.

Do not accidently ruin someone's life with your strange hype idea you
created drunken at 2am at night!

