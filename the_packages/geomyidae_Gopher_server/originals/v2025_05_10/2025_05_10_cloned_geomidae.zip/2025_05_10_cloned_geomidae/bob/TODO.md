* Make eval-bob handle other languages?
* Make eval-bob handle multiple <? ?> tags in a line.
* Buy billboards in Silicon Valley to fight against drunken programming.

