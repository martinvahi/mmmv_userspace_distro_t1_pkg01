#!/bin/sh
echo $* | bc -ql
