# Grammar YACC Tools

Use this Makefile targets to generate lists with internal YACC-commands from ./src/gram.y
