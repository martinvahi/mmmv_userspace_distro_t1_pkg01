| Ingredient |     Amount |       unit |
|-----------:|-----------:|-----------:|
|   Sardines |       1.00 |       kilo |
|    Garlick |       3.00 |       toes |
|    Parsley |       1.00 |      bunch |
| White wine |       1.00 |     bottle |
