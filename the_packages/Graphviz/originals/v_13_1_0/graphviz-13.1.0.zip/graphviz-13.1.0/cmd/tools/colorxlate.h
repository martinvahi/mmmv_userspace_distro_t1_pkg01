#pragma once

#include <util/agxbuf.h>

void colorxlate(char *str, agxbuf *buf);
