#pragma once

#include <pathplan/pathgeom.h>

int Plegal_arrangement(Ppoly_t **polys, size_t n_polys);
