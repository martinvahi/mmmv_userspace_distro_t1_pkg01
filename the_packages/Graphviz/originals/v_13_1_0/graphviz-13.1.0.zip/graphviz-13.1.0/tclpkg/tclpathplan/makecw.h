#pragma once

#include <pathplan/pathutil.h>

void make_CW(Ppoly_t *poly);
