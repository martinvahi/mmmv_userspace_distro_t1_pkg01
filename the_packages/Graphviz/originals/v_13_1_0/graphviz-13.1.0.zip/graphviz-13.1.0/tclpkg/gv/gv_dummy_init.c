#include <gvc/gvc.h>
#include "gv_channel.h"

void gv_string_writer_init (GVC_t *gvc) { (void)gvc; }
void gv_channel_writer_init (GVC_t *gvc) { (void)gvc; }
void gv_writer_reset (GVC_t *gvc) { (void)gvc; }
