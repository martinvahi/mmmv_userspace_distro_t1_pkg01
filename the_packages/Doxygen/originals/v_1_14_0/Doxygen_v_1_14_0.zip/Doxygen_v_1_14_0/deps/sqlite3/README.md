# Contents

This directory contains the "amalgamation" sources of sqlite3 version 3.42.0 as
can be found here: https://www.sqlite.org/download.html

Sqlite3 is used when option `GENERATE_SQLITE3` is enabled to generate sqlite3 database
with the symbols found a project parsed by doxygen.
