#ifndef MD5LOC_H
#define MD5LOC_H

# include <stdint.h>
# define UWORD32 uint32_t

#endif
