README_haiku.txt for version 9.1 of Vim: Vi IMproved.

This file explains the installation of Vim on Haiku operating system.
See "README.txt" for general information about Vim.

Preferred (and easy) way to get Vim on Haiku is to use default Haiku
software repository HaikuPorts. To get Vim:

- Open HaikuDepot application and search for "vim" package, then install,
- Open a Terminal and type "pkgman install vim", then follow instructions.

If you prefer to install Vim from source, follow the instructions on
"runtime/doc/os_haiku.txt", "Compiling Vim" section.
