#!/bin/sh

"${abs_top_builddir:-.}/src/test/test" --fraction 5/8
