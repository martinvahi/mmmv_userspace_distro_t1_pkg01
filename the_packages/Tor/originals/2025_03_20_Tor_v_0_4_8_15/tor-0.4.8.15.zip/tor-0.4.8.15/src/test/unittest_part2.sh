#!/bin/sh

"${abs_top_builddir:-.}/src/test/test" --fraction 2/8
