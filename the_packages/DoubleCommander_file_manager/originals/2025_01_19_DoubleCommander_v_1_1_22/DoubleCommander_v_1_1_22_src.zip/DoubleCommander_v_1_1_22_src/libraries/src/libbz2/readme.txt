libbzip2
https://sourceware.org/pub/bzip2/bzip2-1.0.8.tar.gz
Version 1.0.8 (13/07/2019)
