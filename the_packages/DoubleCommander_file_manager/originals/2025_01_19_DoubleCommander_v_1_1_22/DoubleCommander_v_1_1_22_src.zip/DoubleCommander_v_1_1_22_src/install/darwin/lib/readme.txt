Before create packages (before run create_packages.mac) copy in this directory third-party libraries:
- libunrar.dylib - needed for unrar plugin