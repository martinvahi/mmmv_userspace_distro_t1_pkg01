Before create packages (before run create_packages.sh) copy in this directory third-party libraries:
- libunrar.so - needed for unrar plugin
- libqt4intf.so - needed for qt4 version of Double Commander