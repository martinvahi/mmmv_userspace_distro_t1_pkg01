# Image32

A 2D graphics library written in Delphi Pascal

https://github.com/AngusJohnson/Image32

Version: 4.3+ (2022/10/16)

Author: Angus Johnson