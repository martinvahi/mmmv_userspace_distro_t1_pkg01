var start__free_8hpp =
[
    [ "asio::detail::no_start_free", "de/db4/structasio_1_1detail_1_1no__start__free.html", "de/db4/structasio_1_1detail_1_1no__start__free" ],
    [ "asio::detail::start_free_trait&lt; T, typename &gt;", "d2/d7b/structasio_1_1detail_1_1start__free__trait.html", null ],
    [ "asio::traits::start_free&lt; T, typename &gt;", "da/d8c/structasio_1_1traits_1_1start__free.html", null ],
    [ "asio::traits::start_free_default&lt; T, typename &gt;", "d5/d41/structasio_1_1traits_1_1start__free__default.html", null ]
];