var cpp11_2spawn_2parallel__grep_8cpp =
[
    [ "yield_context", "d0/df8/cpp11_2spawn_2parallel__grep_8cpp.html#a09b73624bafbe0c55f0da6b594cbc886", null ],
    [ "main", "d0/df8/cpp11_2spawn_2parallel__grep_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];