var structtesting_1_1internal_1_1SuiteApiResolver =
[
    [ "Test", "d0/d74/structtesting_1_1internal_1_1SuiteApiResolver.html#af86cc42d09b4ab469fd62ab6414f0629", null ],
    [ "GetSetUpCaseOrSuite", "d0/d74/structtesting_1_1internal_1_1SuiteApiResolver.html#abae647b1fed9422fc596fd385de6dd5b", null ],
    [ "GetTearDownCaseOrSuite", "d0/d74/structtesting_1_1internal_1_1SuiteApiResolver.html#a60e647dc7974c2e834812c491cbbca25", null ]
];