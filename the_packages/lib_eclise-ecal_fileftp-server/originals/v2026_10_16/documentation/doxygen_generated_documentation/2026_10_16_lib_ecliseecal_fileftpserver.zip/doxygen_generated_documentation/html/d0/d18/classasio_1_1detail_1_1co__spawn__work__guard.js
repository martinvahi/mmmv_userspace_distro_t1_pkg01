var classasio_1_1detail_1_1co__spawn__work__guard =
[
    [ "executor_type", "d0/d18/classasio_1_1detail_1_1co__spawn__work__guard.html#aeacd13f6486011cdcf8f529c5fd1c3af", null ],
    [ "co_spawn_work_guard", "d0/d18/classasio_1_1detail_1_1co__spawn__work__guard.html#a6301276b5907fb02100e8df979423856", null ],
    [ "get_executor", "d0/d18/classasio_1_1detail_1_1co__spawn__work__guard.html#a44d4c2c96fd4d8cbe3f7110adac74ddc", null ]
];