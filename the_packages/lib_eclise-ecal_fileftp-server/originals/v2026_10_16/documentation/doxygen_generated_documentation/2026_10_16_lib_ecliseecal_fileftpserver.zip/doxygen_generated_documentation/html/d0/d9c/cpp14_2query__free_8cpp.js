var cpp14_2query__free_8cpp =
[
    [ "object&lt; int &gt;", "da/d78/structobject.html", "da/d78/structobject" ],
    [ "prop&lt; int &gt;", "d2/d58/structprop.html", "d2/d58/structprop" ],
    [ "main", "d0/d9c/cpp14_2query__free_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];