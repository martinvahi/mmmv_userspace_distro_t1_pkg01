var structPredFormatFunctor3 =
[
    [ "operator()", "d0/db4/structPredFormatFunctor3.html#a35575b0ed1e572d3a31603b07a3f6b30", null ]
];