var searchData=
[
  ['0_0',['Release 1.13.0',['../dir_0a153047a1eddfa848544f72ac1a7cd4.html#autotoc_md417',1,'']]]
];
