var structasio_1_1detail_1_1associated__cancellation__slot__impl =
[
    [ "asio_associated_cancellation_slot_is_unspecialised", "d0/dde/structasio_1_1detail_1_1associated__cancellation__slot__impl.html#a3c498e4eed7b664a6d89ab6294a96d29", null ],
    [ "type", "d0/dde/structasio_1_1detail_1_1associated__cancellation__slot__impl.html#a2541a90ab49a45b88fcde2f79820f457", null ],
    [ "get", "d0/dde/structasio_1_1detail_1_1associated__cancellation__slot__impl.html#a3ddee9f66ed5f96fe5684830fd06e022", null ],
    [ "get", "d0/dde/structasio_1_1detail_1_1associated__cancellation__slot__impl.html#ab0aec2a46d9c9661da0b3a3821bdeff8", null ]
];