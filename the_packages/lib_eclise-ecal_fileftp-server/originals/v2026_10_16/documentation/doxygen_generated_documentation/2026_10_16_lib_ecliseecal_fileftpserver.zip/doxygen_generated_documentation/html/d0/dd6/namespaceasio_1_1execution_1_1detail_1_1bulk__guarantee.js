var namespaceasio_1_1execution_1_1detail_1_1bulk__guarantee =
[
    [ "parallel_t", "d9/d69/structasio_1_1execution_1_1detail_1_1bulk__guarantee_1_1parallel__t.html", "d9/d69/structasio_1_1execution_1_1detail_1_1bulk__guarantee_1_1parallel__t" ],
    [ "sequenced_t", "d3/d1f/structasio_1_1execution_1_1detail_1_1bulk__guarantee_1_1sequenced__t.html", "d3/d1f/structasio_1_1execution_1_1detail_1_1bulk__guarantee_1_1sequenced__t" ],
    [ "unsequenced_t", "d1/d4c/structasio_1_1execution_1_1detail_1_1bulk__guarantee_1_1unsequenced__t.html", "d1/d4c/structasio_1_1execution_1_1detail_1_1bulk__guarantee_1_1unsequenced__t" ]
];