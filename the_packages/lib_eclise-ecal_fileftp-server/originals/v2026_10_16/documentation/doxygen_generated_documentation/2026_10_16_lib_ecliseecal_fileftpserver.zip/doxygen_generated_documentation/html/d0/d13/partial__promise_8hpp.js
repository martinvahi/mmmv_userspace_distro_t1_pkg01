var partial__promise_8hpp =
[
    [ "asio::experimental::detail::partial_coro", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#d0/da9/structasio_1_1experimental_1_1detail_1_1partial__coro", [
      [ "handle", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#aa44a7adab7562be1d13dc94c85dc5a76", null ]
    ] ],
    [ "asio::experimental::detail::partial_promise&lt; Allocator &gt;", "dd/dba/structasio_1_1experimental_1_1detail_1_1partial__promise.html", "dd/dba/structasio_1_1experimental_1_1detail_1_1partial__promise" ],
    [ "asio::experimental::detail::partial_promise_base&lt; Allocator &gt;", "dc/de8/structasio_1_1experimental_1_1detail_1_1partial__promise__base.html", "dc/de8/structasio_1_1experimental_1_1detail_1_1partial__promise__base" ],
    [ "asio::experimental::detail::partial_promise_base&lt; std::allocator&lt; void &gt; &gt;", "df/daa/structasio_1_1experimental_1_1detail_1_1partial__promise__base_3_01std_1_1allocator_3_01void_01_4_01_4.html", "df/daa/structasio_1_1experimental_1_1detail_1_1partial__promise__base_3_01std_1_1allocator_3_01void_01_4_01_4" ],
    [ "std::experimental::coroutine_traits&lt; asio::experimental::detail::partial_coro, Executor, Completion, Args... &gt;", "de/d97/namespacestd_1_1experimental.html#dc/d0d/structstd_1_1experimental_1_1coroutine__traits_3_01asio_1_1experimental_1_1detail_1_1partial__co0760e2a553e3fc55c5679580d7993c9e", [
      [ "promise_type", "de/d97/namespacestd_1_1experimental.html#a310a8a11489ced2417e5c12fd7d62fa2", null ]
    ] ],
    [ "asio::experimental::detail::dispatch_coroutine", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#a92d864b2f6e496825caf574ce27c7e89", null ],
    [ "asio::experimental::detail::dispatch_coroutine", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#ab15d806e46ef85652e8afd59b996c0b3", null ],
    [ "asio::experimental::detail::post_coroutine", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#acdf29fc2afaf2b8560a78864d07912a6", null ],
    [ "asio::experimental::detail::post_coroutine", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#aa0168fa9c9fac03a24f2399fdd08de31", null ]
];