var searchData=
[
  ['namedenum_0',['NamedEnum',['../d2/da7/namespaceanonymous__namespace_02gtest__unittest_8cc_03.html#ae6ac9f784a29098a747d009f12a0f5a7',1,'anonymous_namespace{gtest_unittest.cc}']]],
  ['netdb_5ferrors_1',['netdb_errors',['../dd/df8/namespaceasio_1_1error.html#aca1d28016f48d8f815c602788bc466de',1,'asio::error']]]
];
