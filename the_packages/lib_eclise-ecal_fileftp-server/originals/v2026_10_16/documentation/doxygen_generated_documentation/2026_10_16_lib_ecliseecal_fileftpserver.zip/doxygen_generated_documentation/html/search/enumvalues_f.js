var searchData=
[
  ['read_5fop_0',['read_op',['../d0/db9/classasio_1_1detail_1_1select__reactor.html#aa68ba3d214f9f046a27ad6b4ad743b37ab22de8bbf84e6d43de4e6f6a8bf70da5',1,'asio::detail::select_reactor']]],
  ['readonly_1',['ReadOnly',['../d5/d4e/namespacefineftp.html#a4db09014ff4677cffdee958f2e8d1cdfa131fb182a881796e7606ed6da27f1197',1,'fineftp']]],
  ['redirect_2',['redirect',['../dc/de5/classicmp__header.html#a648fd991e2280a29d2c5bc9bd3c33623a79484ba871e5efba55d67a442f405642',1,'icmp_header']]],
  ['regularfile_3',['RegularFile',['../d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa81c4fe0f81a2ac8c3a1a10d9740f46c9',1,'fineftp::Filesystem']]],
  ['reply_5frestart_5fmarker_4',['REPLY_RESTART_MARKER',['../d5/d4e/namespacefineftp.html#a755c9dea68c90ff41b25a1d01ac2f3f5aeb302dbc4611190fa47176337d72d37c',1,'fineftp']]],
  ['reply_5fsystem_5fstatus_5',['REPLY_SYSTEM_STATUS',['../d5/d4e/namespacefineftp.html#a755c9dea68c90ff41b25a1d01ac2f3f5ae87aad07eae2139fd76bb735e94459df',1,'fineftp']]],
  ['request_5ffailed_6',['request_failed',['../dc/da0/classsocks4_1_1reply.html#a19dcc77721e693067f2abef5dfa78552abd8c6eaf782da9c9efb9617c95e0f5a4',1,'socks4::reply']]],
  ['request_5ffailed_5fbad_5fuser_5fid_7',['request_failed_bad_user_id',['../dc/da0/classsocks4_1_1reply.html#a19dcc77721e693067f2abef5dfa78552ac3a86835c2b2c6a7e89e26c5ba01310c',1,'socks4::reply']]],
  ['request_5ffailed_5fno_5fidentd_8',['request_failed_no_identd',['../dc/da0/classsocks4_1_1reply.html#a19dcc77721e693067f2abef5dfa78552a67a4dab34c458735499be5a232aecd9c',1,'socks4::reply']]],
  ['request_5fgranted_9',['request_granted',['../dc/da0/classsocks4_1_1reply.html#a19dcc77721e693067f2abef5dfa78552a9ba594fa21240bf3665c7d774ec50ab8',1,'socks4::reply']]],
  ['restart_10',['restart',['../db/dc1/structasio_1_1signal__set__base_1_1flags.html#a4c2a1046d4c24839193ab3f011424ed8abe4fd89be708c32e6044d0292ea32e36',1,'asio::signal_set_base::flags']]]
];
