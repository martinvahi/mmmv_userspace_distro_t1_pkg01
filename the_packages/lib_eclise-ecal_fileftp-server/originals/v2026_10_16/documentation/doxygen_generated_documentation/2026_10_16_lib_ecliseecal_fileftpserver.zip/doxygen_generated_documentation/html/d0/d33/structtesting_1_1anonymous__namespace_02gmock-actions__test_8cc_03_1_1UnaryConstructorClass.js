var structtesting_1_1anonymous__namespace_02gmock_actions__test_8cc_03_1_1UnaryConstructorClass =
[
    [ "UnaryConstructorClass", "d0/d33/structtesting_1_1anonymous__namespace_02gmock-actions__test_8cc_03_1_1UnaryConstructorClass.html#a1cce9c0704e74bf66682fe4ee17c1b87", null ],
    [ "value", "d0/d33/structtesting_1_1anonymous__namespace_02gmock-actions__test_8cc_03_1_1UnaryConstructorClass.html#a4f1311c7160fcac2d26ba53ea2b21073", null ]
];