var searchData=
[
  ['half_5for_5ffull_5ft_0',['half_or_full_t',['../db/d72/classasio_1_1detail_1_1null__fenced__block.html#a21c66218b4c10beb58f227cc40b655df',1,'asio::detail::null_fenced_block']]],
  ['handshake_5ftype_1',['handshake_type',['../d4/de3/classasio_1_1ssl_1_1stream__base.html#a2f18813d3860bc8aee99249834d7c320',1,'asio::ssl::stream_base']]]
];
