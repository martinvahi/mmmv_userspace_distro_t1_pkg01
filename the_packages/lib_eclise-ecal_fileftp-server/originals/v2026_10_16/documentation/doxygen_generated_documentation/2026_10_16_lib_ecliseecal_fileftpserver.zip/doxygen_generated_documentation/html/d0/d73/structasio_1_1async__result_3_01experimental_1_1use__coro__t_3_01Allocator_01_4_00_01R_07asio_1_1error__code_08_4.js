var structasio_1_1async__result_3_01experimental_1_1use__coro__t_3_01Allocator_01_4_00_01R_07asio_1_1error__code_08_4 =
[
    [ "async_result", "df/d83/classasio_1_1async__result.html#a25603cac24c1f80b2dc2e3172392966f", null ],
    [ "initiate", "d0/d73/structasio_1_1async__result_3_01experimental_1_1use__coro__t_3_01Allocator_01_4_00_01R_07asio_1_1error__code_08_4.html#af67aff7fe831861e9ebe872b84aa1e7a", null ],
    [ "initiate_impl", "d0/d73/structasio_1_1async__result_3_01experimental_1_1use__coro__t_3_01Allocator_01_4_00_01R_07asio_1_1error__code_08_4.html#a64ebe0f04e91ff517259438dfd66c54b", null ],
    [ "initiate_impl", "d0/d73/structasio_1_1async__result_3_01experimental_1_1use__coro__t_3_01Allocator_01_4_00_01R_07asio_1_1error__code_08_4.html#a7f75f832f10e19664c8774bbc14c0e8b", null ]
];