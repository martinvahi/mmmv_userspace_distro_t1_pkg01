var impl_2as__single_8hpp =
[
    [ "asio::associator&lt; Associator, experimental::detail::as_single_handler&lt; Handler &gt;, DefaultCandidate &gt;", "d5/de4/structasio_1_1associator_3_01Associator_00_01experimental_1_1detail_1_1as__single__handler_3_01H6c2fad8b25c05174c255b98fc93985b6.html", "d5/de4/structasio_1_1associator_3_01Associator_00_01experimental_1_1detail_1_1as__single__handler_3_01H6c2fad8b25c05174c255b98fc93985b6" ],
    [ "asio::async_result&lt; experimental::as_single_t&lt; CompletionToken &gt;, Signature &gt;", "da/da8/structasio_1_1async__result_3_01experimental_1_1as__single__t_3_01CompletionToken_01_4_00_01Signature_01_4.html", "da/da8/structasio_1_1async__result_3_01experimental_1_1as__single__t_3_01CompletionToken_01_4_00_01Signature_01_4" ],
    [ "asio::async_result&lt; experimental::as_single_t&lt; CompletionToken &gt;, Signature &gt;::init_wrapper&lt; Initiation &gt;", "de/d5c/structasio_1_1async__result_3_01experimental_1_1as__single__t_3_01CompletionToken_01_4_00_01Signature_01_4_1_1init__wrapper.html", "de/d5c/structasio_1_1async__result_3_01experimental_1_1as__single__t_3_01CompletionToken_01_4_00_01Signature_01_4_1_1init__wrapper" ],
    [ "asio::experimental::detail::as_single_handler&lt; Handler &gt;", "dc/d7f/classasio_1_1experimental_1_1detail_1_1as__single__handler.html", "dc/d7f/classasio_1_1experimental_1_1detail_1_1as__single__handler" ],
    [ "asio::experimental::detail::as_single_signature&lt; R()&gt;", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#de/d9a/structasio_1_1experimental_1_1detail_1_1as__single__signature_3_01R_07_08_4", [
      [ "type", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#adb0f7ce27aca459a7843502a182dc171", null ]
    ] ],
    [ "asio::experimental::detail::as_single_signature&lt; R(Arg)&gt;", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#d0/d32/structasio_1_1experimental_1_1detail_1_1as__single__signature_3_01R_07Arg_08_4", [
      [ "type", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#a1d9cf48a83daa3332694e1d5ddedbcde", null ]
    ] ],
    [ "asio::experimental::detail::as_single_signature&lt; R(Args...)&gt;", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#d8/d0b/structasio_1_1experimental_1_1detail_1_1as__single__signature_3_01R_07Args_8_8_8_08_4", [
      [ "type", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#a5e6b5e5de4c83066e0e268bcb6a4cc4d", null ]
    ] ],
    [ "asio::experimental::detail::as_single_signature&lt; Signature &gt;", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#d8/d52/structasio_1_1experimental_1_1detail_1_1as__single__signature", [
      [ "type", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#aef78c7f4c4766edb4791eaf4caf5cd62", null ]
    ] ],
    [ "asio::experimental::detail::asio_handler_allocate", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#a59783c60b4815a88238dd10f34289a7e", null ],
    [ "asio::experimental::detail::asio_handler_deallocate", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#adce2449ff503ac1ddf810264f75b73e3", null ],
    [ "asio::experimental::detail::asio_handler_invoke", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#ad785c8ca9ba7e8cf39a219245c875ef7", null ],
    [ "asio::experimental::detail::asio_handler_invoke", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#ad669f61065e1064bf81df0d1e33fa489", null ],
    [ "asio::experimental::detail::asio_handler_is_continuation", "d6/db9/namespaceasio_1_1experimental_1_1detail.html#af15f5c5da5c2e172988411f59d8470c9", null ]
];