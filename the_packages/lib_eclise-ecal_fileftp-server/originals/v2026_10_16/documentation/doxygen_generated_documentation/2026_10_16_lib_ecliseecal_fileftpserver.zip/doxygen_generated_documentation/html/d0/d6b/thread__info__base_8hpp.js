var thread__info__base_8hpp =
[
    [ "asio::detail::thread_info_base", "dc/d5e/classasio_1_1detail_1_1thread__info__base.html", "dc/d5e/classasio_1_1detail_1_1thread__info__base" ],
    [ "asio::detail::thread_info_base::awaitable_frame_tag", "d7/ded/structasio_1_1detail_1_1thread__info__base_1_1awaitable__frame__tag.html", null ],
    [ "asio::detail::thread_info_base::cancellation_signal_tag", "d1/d9a/structasio_1_1detail_1_1thread__info__base_1_1cancellation__signal__tag.html", null ],
    [ "asio::detail::thread_info_base::default_tag", "d1/dba/structasio_1_1detail_1_1thread__info__base_1_1default__tag.html", null ],
    [ "asio::detail::thread_info_base::executor_function_tag", "d4/de7/structasio_1_1detail_1_1thread__info__base_1_1executor__function__tag.html", null ],
    [ "asio::detail::thread_info_base::parallel_group_tag", "dd/d5b/structasio_1_1detail_1_1thread__info__base_1_1parallel__group__tag.html", null ],
    [ "ASIO_RECYCLING_ALLOCATOR_CACHE_SIZE", "d0/d6b/thread__info__base_8hpp.html#adb3a89d59ccb5fe17316fb7714cab0da", null ]
];