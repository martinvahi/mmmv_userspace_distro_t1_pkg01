var completion__handler_8hpp =
[
    [ "asio::detail::completion_handler&lt; Handler, IoExecutor &gt;", "d1/d58/classasio_1_1detail_1_1completion__handler.html", "d1/d58/classasio_1_1detail_1_1completion__handler" ]
];