var namespacefineftp_1_1Filesystem =
[
    [ "FileStatus", "d7/d88/classfineftp_1_1Filesystem_1_1FileStatus.html", "d7/d88/classfineftp_1_1Filesystem_1_1FileStatus" ],
    [ "FileType", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3af", [
      [ "Unknown", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa88183b946cc5f0e8c96b2e66e1c74a7e", null ],
      [ "RegularFile", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa81c4fe0f81a2ac8c3a1a10d9740f46c9", null ],
      [ "Dir", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa3c4e6dbf3e1df93a734d9959bac9ee94", null ],
      [ "CharacterDevice", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afaffe13ab2336b3e46f735a9fb461dc0e5", null ],
      [ "BlockDevice", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa1cce59ace6a1a0cb0561d33037b20942", null ],
      [ "Fifo", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afaa0476ca4d7283b340d24c53c16270958", null ],
      [ "SymbolicLink", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afaab3e5ceb5884bafd3068b93e7c63cae5", null ],
      [ "Socket", "d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa69f69b59aae6f4ee1a47bbc1086ecdb4", null ]
    ] ],
    [ "cleanPath", "d0/d6d/namespacefineftp_1_1Filesystem.html#a10d236831ec5293000eb3399f4345c01", null ],
    [ "cleanPathNative", "d0/d6d/namespacefineftp_1_1Filesystem.html#acd6527362006282530c80779748d8e92", null ],
    [ "dirContent", "d0/d6d/namespacefineftp_1_1Filesystem.html#ab8c36583af4a6a8f067bc1f713202d7c", null ]
];