var searchData=
[
  ['password_5fpurpose_0',['password_purpose',['../d2/de6/classasio_1_1ssl_1_1context__base.html#a0e5aec1cd0f3db28becde1dca686c855',1,'asio::ssl::context_base']]],
  ['permission_1',['Permission',['../d5/d4e/namespacefineftp.html#a4db09014ff4677cffdee958f2e8d1cdf',1,'fineftp']]]
];
