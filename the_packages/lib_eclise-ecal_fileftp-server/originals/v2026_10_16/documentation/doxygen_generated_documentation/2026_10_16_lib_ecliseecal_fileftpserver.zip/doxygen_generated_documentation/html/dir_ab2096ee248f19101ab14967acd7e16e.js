var dir_ab2096ee248f19101ab14967acd7e16e =
[
    [ "connect_pair.cpp", "d7/d92/examples_2cpp03_2local_2connect__pair_8cpp.html", null ],
    [ "iostream_client.cpp", "de/dbc/cpp03_2local_2iostream__client_8cpp.html", null ],
    [ "stream_client.cpp", "d8/d20/cpp03_2local_2stream__client_8cpp.html", null ],
    [ "stream_server.cpp", "d0/d06/cpp03_2local_2stream__server_8cpp.html", null ]
];