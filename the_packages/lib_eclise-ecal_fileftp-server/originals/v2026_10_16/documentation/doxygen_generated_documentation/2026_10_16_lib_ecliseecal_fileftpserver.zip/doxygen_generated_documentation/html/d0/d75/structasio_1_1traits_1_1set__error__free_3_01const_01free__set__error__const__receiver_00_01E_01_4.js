var structasio_1_1traits_1_1set__error__free_3_01const_01free__set__error__const__receiver_00_01E_01_4 =
[
    [ "result_type", "d0/d75/structasio_1_1traits_1_1set__error__free_3_01const_01free__set__error__const__receiver_00_01E_01_4.html#a5a5bd6cb47bb68cda72f64cb3d3a1f98", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d75/structasio_1_1traits_1_1set__error__free_3_01const_01free__set__error__const__receiver_00_01E_01_4.html#aac15693f25cbfe968d29346518b230d6", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d75/structasio_1_1traits_1_1set__error__free_3_01const_01free__set__error__const__receiver_00_01E_01_4.html#aa10836a4a08ee9f4d52274effb39b4ad", null ]
];