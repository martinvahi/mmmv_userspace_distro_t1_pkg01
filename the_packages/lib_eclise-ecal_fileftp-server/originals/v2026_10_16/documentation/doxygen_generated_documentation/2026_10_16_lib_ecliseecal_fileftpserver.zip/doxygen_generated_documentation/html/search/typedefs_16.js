var searchData=
[
  ['weak_5fcancel_5ftoken_5ftype_0',['weak_cancel_token_type',['../de/d96/namespaceasio_1_1detail_1_1socket__ops.html#a9dbe5bfa22a69dc9a583a8060228860f',1,'asio::detail::socket_ops']]]
];
