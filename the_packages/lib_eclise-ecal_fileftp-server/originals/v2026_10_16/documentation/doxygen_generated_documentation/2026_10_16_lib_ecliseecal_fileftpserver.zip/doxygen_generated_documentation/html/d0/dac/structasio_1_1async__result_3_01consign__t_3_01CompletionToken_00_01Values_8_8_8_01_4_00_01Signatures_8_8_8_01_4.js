var structasio_1_1async__result_3_01consign__t_3_01CompletionToken_00_01Values_8_8_8_01_4_00_01Signatures_8_8_8_01_4 =
[
    [ "init_wrapper", "d9/d9a/structasio_1_1async__result_3_01consign__t_3_01CompletionToken_00_01Values_8_8_8_01_4_00_01Signa9729cc41e0af16911366c362447be367.html", "d9/d9a/structasio_1_1async__result_3_01consign__t_3_01CompletionToken_00_01Values_8_8_8_01_4_00_01Signa9729cc41e0af16911366c362447be367" ],
    [ "async_result", "df/d83/classasio_1_1async__result.html#a25603cac24c1f80b2dc2e3172392966f", null ],
    [ "ASIO_INITFN_DEDUCED_RESULT_TYPE", "d0/dac/structasio_1_1async__result_3_01consign__t_3_01CompletionToken_00_01Values_8_8_8_01_4_00_01Signatures_8_8_8_01_4.html#ad13c488b7a21b8bff7378254a8b2b314", null ],
    [ "ASIO_MOVE_ARG", "d0/dac/structasio_1_1async__result_3_01consign__t_3_01CompletionToken_00_01Values_8_8_8_01_4_00_01Signatures_8_8_8_01_4.html#adda38d25a41225f2585ce51a68ef6f24", null ],
    [ "ASIO_MOVE_ARG", "d0/dac/structasio_1_1async__result_3_01consign__t_3_01CompletionToken_00_01Values_8_8_8_01_4_00_01Signatures_8_8_8_01_4.html#a4054f9786dced6d1bd99e7978d41b9d5", null ]
];