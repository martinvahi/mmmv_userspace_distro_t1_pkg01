var searchData=
[
  ['unauthorized_0',['unauthorized',['../dc/d26/structhttp_1_1server_1_1reply.html#a08d3b8d638988f252ab4e5cd3db72ad6ac71e7b466f7ac4498cd5a78954420e9d',1,'http::server::reply::unauthorized'],['../d8/df0/structhttp_1_1server2_1_1reply.html#a3fa790dc50a0fe3158fea8014395f37fa223ca3aaff1b29900d87bbcb85517447',1,'http::server2::reply::unauthorized'],['../d3/dd2/structhttp_1_1server3_1_1reply.html#abf2ead1365da33f8d7cbe24816d070d1acd2f21a63fcf41fa4c76ff26729817ec',1,'http::server3::reply::unauthorized'],['../dc/d4f/structhttp_1_1server4_1_1reply.html#a2c75caf04d09f0ca6b485c847be2aa05aed3d4ac6c2062f1d2c12b7d664b06157',1,'http::server4::reply::unauthorized']]],
  ['unexpected_5fresult_1',['unexpected_result',['../d9/d8d/namespaceasio_1_1ssl_1_1error.html#af5923c8b6f1383a625ee7293be063321a743b095b1b62f0f70d3ef54ebb568167',1,'asio::ssl::error']]],
  ['unknown_2',['Unknown',['../d0/d6d/namespacefineftp_1_1Filesystem.html#aaf5a38d8a786352862b38f523fa6f3afa88183b946cc5f0e8c96b2e66e1c74a7e',1,'fineftp::Filesystem']]],
  ['unspecified_5fsystem_5ferror_3',['unspecified_system_error',['../d9/d8d/namespaceasio_1_1ssl_1_1error.html#af5923c8b6f1383a625ee7293be063321a873d66e5293e5ad11da9f2e9aa52c67d',1,'asio::ssl::error']]],
  ['user_5flogged_5fin_4',['USER_LOGGED_IN',['../d5/d4e/namespacefineftp.html#a755c9dea68c90ff41b25a1d01ac2f3f5a6109c86e1ea15bf30ee6c9515dcdfd41',1,'fineftp']]],
  ['user_5fname_5fok_5',['USER_NAME_OK',['../d5/d4e/namespacefineftp.html#a755c9dea68c90ff41b25a1d01ac2f3f5a913869b5c3952106e293510e615658ae',1,'fineftp']]],
  ['user_5fset_5flinger_6',['user_set_linger',['../de/d96/namespaceasio_1_1detail_1_1socket__ops.html#a74a80b850015f6392d33a30de37905fea1ee8676ef17dc218d9e2a0f3476448e7',1,'asio::detail::socket_ops']]],
  ['user_5fset_5fnon_5fblocking_7',['user_set_non_blocking',['../dc/d79/namespaceasio_1_1detail_1_1descriptor__ops.html#abd4dade63a12a16be951750e23c80d98abc2ae064c1ea10a1c92b27ad21098a6d',1,'asio::detail::descriptor_ops::user_set_non_blocking'],['../de/d96/namespaceasio_1_1detail_1_1socket__ops.html#a74a80b850015f6392d33a30de37905fea4f960990a3814108246f236f45ef1131',1,'asio::detail::socket_ops::user_set_non_blocking']]]
];
