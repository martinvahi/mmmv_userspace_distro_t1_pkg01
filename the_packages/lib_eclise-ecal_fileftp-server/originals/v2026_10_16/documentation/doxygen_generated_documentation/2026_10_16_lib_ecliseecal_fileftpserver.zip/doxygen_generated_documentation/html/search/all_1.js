var searchData=
[
  ['1_2013_200_0',['Release 1.13.0',['../dir_0a153047a1eddfa848544f72ac1a7cd4.html#autotoc_md417',1,'']]],
  ['13_200_1',['Release 1.13.0',['../dir_0a153047a1eddfa848544f72ac1a7cd4.html#autotoc_md417',1,'']]],
  ['1_3a_20integrate_20as_20binaries_2',['Option 1: Integrate as binaries',['../dir_6a35cfd0f7be8a21012f81c494c374ef.html#autotoc_md7',1,'']]]
];
