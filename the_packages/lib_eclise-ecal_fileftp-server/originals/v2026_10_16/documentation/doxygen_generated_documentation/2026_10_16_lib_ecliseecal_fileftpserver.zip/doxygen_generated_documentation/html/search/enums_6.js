var searchData=
[
  ['gtestcolor_0',['GTestColor',['../de/daf/namespacetesting_1_1internal_1_1anonymous__namespace_02gtest_8cc_03.html#a4836e817e40110ef914cb8e20ba96666',1,'testing::internal::anonymous_namespace{gtest.cc}']]],
  ['gtestlogseverity_1',['GTestLogSeverity',['../d0/da7/namespacetesting_1_1internal.html#aa6255ef3b023c5b4e1a2198d887fb977',1,'testing::internal']]]
];
