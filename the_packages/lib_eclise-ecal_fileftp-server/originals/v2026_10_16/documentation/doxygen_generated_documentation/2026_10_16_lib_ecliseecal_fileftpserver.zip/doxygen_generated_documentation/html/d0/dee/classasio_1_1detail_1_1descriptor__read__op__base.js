var classasio_1_1detail_1_1descriptor__read__op__base =
[
    [ "descriptor_read_op_base", "d0/dee/classasio_1_1detail_1_1descriptor__read__op__base.html#a8474a4071286ace4d84d7b38e9a6d653", null ],
    [ "do_perform", "d0/dee/classasio_1_1detail_1_1descriptor__read__op__base.html#a492c05f3644b44f2a9acbdc4e6e35e0b", null ]
];