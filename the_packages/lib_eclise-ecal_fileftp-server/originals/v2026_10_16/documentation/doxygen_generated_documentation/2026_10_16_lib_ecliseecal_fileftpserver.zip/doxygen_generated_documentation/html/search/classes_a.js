var searchData=
[
  ['kindof_0',['KindOf',['../dc/d66/structtesting_1_1internal_1_1KindOf.html',1,'testing::internal']]]
];
