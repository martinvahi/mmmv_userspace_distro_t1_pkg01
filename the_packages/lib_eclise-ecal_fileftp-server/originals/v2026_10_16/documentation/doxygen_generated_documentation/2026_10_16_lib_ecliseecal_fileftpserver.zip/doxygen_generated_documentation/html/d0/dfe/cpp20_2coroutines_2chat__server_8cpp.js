var cpp20_2coroutines_2chat__server_8cpp =
[
    [ "chat_participant", "db/dcd/classchat__participant.html", "db/dcd/classchat__participant" ],
    [ "chat_room", "d3/d2a/classchat__room.html", "d3/d2a/classchat__room" ],
    [ "chat_session", "db/dcb/classchat__session.html", "db/dcb/classchat__session" ],
    [ "chat_participant_ptr", "d0/dfe/cpp20_2coroutines_2chat__server_8cpp.html#a57438281b6b1e9d47e5c9e4b386b60f2", null ],
    [ "listener", "d0/dfe/cpp20_2coroutines_2chat__server_8cpp.html#abaaaabe894770377f2a53a5b9402b60c", null ],
    [ "main", "d0/dfe/cpp20_2coroutines_2chat__server_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "redirect_error", "d0/dfe/cpp20_2coroutines_2chat__server_8cpp.html#aaf2dc4bc523764497147013d1c3ef4eb", null ]
];