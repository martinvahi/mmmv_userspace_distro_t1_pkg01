var handler__alloc__helpers_8hpp =
[
    [ "asio::detail::get_hook_allocator&lt; Handler, Allocator &gt;", "dd/d11/structasio_1_1detail_1_1get__hook__allocator.html", "dd/d11/structasio_1_1detail_1_1get__hook__allocator" ],
    [ "asio::detail::get_hook_allocator&lt; Handler, std::allocator&lt; T &gt; &gt;", "d3/d87/structasio_1_1detail_1_1get__hook__allocator_3_01Handler_00_01std_1_1allocator_3_01T_01_4_01_4.html", "d3/d87/structasio_1_1detail_1_1get__hook__allocator_3_01Handler_00_01std_1_1allocator_3_01T_01_4_01_4" ],
    [ "asio::detail::hook_allocator&lt; Handler, T &gt;", "dd/dc1/classasio_1_1detail_1_1hook__allocator.html", "dd/dc1/classasio_1_1detail_1_1hook__allocator" ],
    [ "asio::detail::hook_allocator&lt; Handler, T &gt;::rebind&lt; U &gt;", "dd/dc1/classasio_1_1detail_1_1hook__allocator.html#d7/d93/structasio_1_1detail_1_1hook__allocator_1_1rebind", [
      [ "other", "dd/dc1/classasio_1_1detail_1_1hook__allocator.html#a8f6dac5c66bfca72579386d6afa5dd7b", null ]
    ] ],
    [ "asio::detail::hook_allocator&lt; Handler, void &gt;", "d5/d25/classasio_1_1detail_1_1hook__allocator_3_01Handler_00_01void_01_4.html", "d5/d25/classasio_1_1detail_1_1hook__allocator_3_01Handler_00_01void_01_4" ],
    [ "asio::detail::hook_allocator&lt; Handler, void &gt;::rebind&lt; U &gt;", "d5/d25/classasio_1_1detail_1_1hook__allocator_3_01Handler_00_01void_01_4.html#d0/dd0/structasio_1_1detail_1_1hook__allocator_3_01Handler_00_01void_01_4_1_1rebind", [
      [ "other", "d5/d25/classasio_1_1detail_1_1hook__allocator_3_01Handler_00_01void_01_4.html#a0e552b073747a9bee32b67e763b47124", null ]
    ] ],
    [ "ASIO_DEFINE_HANDLER_ALLOCATOR_PTR", "d0/d6c/handler__alloc__helpers_8hpp.html#aef8fcd445b85af26d94b4dd170f7d03c", null ],
    [ "ASIO_DEFINE_HANDLER_PTR", "d0/d6c/handler__alloc__helpers_8hpp.html#a6689437c03532e3fee2c08e23992f1c4", null ],
    [ "ASIO_DEFINE_TAGGED_HANDLER_ALLOCATOR_PTR", "d0/d6c/handler__alloc__helpers_8hpp.html#accf4b1e98740c3bc99958bf8f251f12a", null ],
    [ "asio_handler_alloc_helpers::allocate", "de/d66/namespaceasio__handler__alloc__helpers.html#aef2de2816b30a8e02c604dcb9dcf94a5", null ],
    [ "asio_handler_alloc_helpers::deallocate", "de/d66/namespaceasio__handler__alloc__helpers.html#a68190ffdc7b1fef0054d8359cd1d0d6b", null ]
];