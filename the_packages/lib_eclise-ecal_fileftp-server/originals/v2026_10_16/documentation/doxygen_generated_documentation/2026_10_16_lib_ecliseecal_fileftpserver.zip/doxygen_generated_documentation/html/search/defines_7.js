var searchData=
[
  ['joiner_0',['JOINER',['../dd/dda/gmock-pp-string__test_8cc.html#a417889002d582097e444f103350c05cb',1,'gmock-pp-string_test.cc']]],
  ['joiner_5fcat_1',['JOINER_CAT',['../dd/dda/gmock-pp-string__test_8cc.html#a061e03ac22467881369813e8d73ddf61',1,'gmock-pp-string_test.cc']]]
];
