var classasio_1_1error_1_1detail_1_1ssl__category =
[
    [ "message", "d0/d33/classasio_1_1error_1_1detail_1_1ssl__category.html#a0407d92349dfa5b2a2ebf4cd9213fa6e", null ],
    [ "name", "d0/d33/classasio_1_1error_1_1detail_1_1ssl__category.html#a9d7864c9dba3ba9649388731118a3e58", null ]
];