var base__from__completion__cond_8hpp =
[
    [ "asio::detail::base_from_completion_cond&lt; CompletionCondition &gt;", "dd/d0d/classasio_1_1detail_1_1base__from__completion__cond.html", "dd/d0d/classasio_1_1detail_1_1base__from__completion__cond" ],
    [ "asio::detail::base_from_completion_cond&lt; transfer_all_t &gt;", "d9/de1/classasio_1_1detail_1_1base__from__completion__cond_3_01transfer__all__t_01_4.html", "d9/de1/classasio_1_1detail_1_1base__from__completion__cond_3_01transfer__all__t_01_4" ]
];