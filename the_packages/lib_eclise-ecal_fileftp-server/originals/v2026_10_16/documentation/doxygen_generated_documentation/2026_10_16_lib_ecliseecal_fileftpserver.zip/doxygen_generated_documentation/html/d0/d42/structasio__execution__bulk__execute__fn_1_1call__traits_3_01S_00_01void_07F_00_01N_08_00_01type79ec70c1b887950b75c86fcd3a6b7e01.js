var structasio__execution__bulk__execute__fn_1_1call__traits_3_01S_00_01void_07F_00_01N_08_00_01type79ec70c1b887950b75c86fcd3a6b7e01 =
[
    [ "result_type", "d5/d63/structasio__execution__bulk__execute__fn_1_1call__traits.html#a47a560eff3d88d2fe05ac18fed161820", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d42/structasio__execution__bulk__execute__fn_1_1call__traits_3_01S_00_01void_07F_00_01N_08_00_01type79ec70c1b887950b75c86fcd3a6b7e01.html#a7cd52e556c87397d85061047af9b6749", null ]
];