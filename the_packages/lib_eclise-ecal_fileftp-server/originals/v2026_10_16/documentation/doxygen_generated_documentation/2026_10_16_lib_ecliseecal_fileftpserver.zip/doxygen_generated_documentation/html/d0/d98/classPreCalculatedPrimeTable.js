var classPreCalculatedPrimeTable =
[
    [ "PreCalculatedPrimeTable", "d0/d98/classPreCalculatedPrimeTable.html#a6bb947504421e31da70d2c71576be350", null ],
    [ "~PreCalculatedPrimeTable", "d0/d98/classPreCalculatedPrimeTable.html#aeb9fb66a80367344b6ffe9c343b73464", null ],
    [ "GetNextPrime", "d0/d98/classPreCalculatedPrimeTable.html#a0b99de0a790db9f0cc2b3cd4b527fd5a", null ],
    [ "IsPrime", "d0/d98/classPreCalculatedPrimeTable.html#a62be946777f7f98bbfc01edc0f15a4bb", null ]
];