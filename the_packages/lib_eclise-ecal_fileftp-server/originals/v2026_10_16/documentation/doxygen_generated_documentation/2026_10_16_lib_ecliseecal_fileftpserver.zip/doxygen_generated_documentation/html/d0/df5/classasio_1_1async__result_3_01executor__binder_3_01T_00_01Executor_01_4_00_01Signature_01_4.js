var classasio_1_1async__result_3_01executor__binder_3_01T_00_01Executor_01_4_00_01Signature_01_4 =
[
    [ "init_wrapper", "d1/d27/structasio_1_1async__result_3_01executor__binder_3_01T_00_01Executor_01_4_00_01Signature_01_4_1_1init__wrapper.html", "d1/d27/structasio_1_1async__result_3_01executor__binder_3_01T_00_01Executor_01_4_00_01Signature_01_4_1_1init__wrapper" ],
    [ "async_result", "d0/df5/classasio_1_1async__result_3_01executor__binder_3_01T_00_01Executor_01_4_00_01Signature_01_4.html#a71eea66ae7d615b3e2754428e5e53755", null ],
    [ "ASIO_INITFN_DEDUCED_RESULT_TYPE", "d0/df5/classasio_1_1async__result_3_01executor__binder_3_01T_00_01Executor_01_4_00_01Signature_01_4.html#a599d46d2dd7bd3b446b19986da9ab767", null ],
    [ "ASIO_MOVE_ARG", "d0/df5/classasio_1_1async__result_3_01executor__binder_3_01T_00_01Executor_01_4_00_01Signature_01_4.html#a902cad780376c3699b70f739a9473b63", null ]
];