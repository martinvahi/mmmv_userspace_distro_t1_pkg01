var searchData=
[
  ['join_5fguard_0',['join_guard',['../d4/d02/classjoin__guard.html',1,'']]]
];
