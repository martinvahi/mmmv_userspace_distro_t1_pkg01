var searchData=
[
  ['my_5fnamespace_0',['my_namespace',['../d4/d0f/namespacemy__namespace.html',1,'']]],
  ['my_5fnamespace_3a_3atesting_1',['testing',['../d8/d72/namespacemy__namespace_1_1testing.html',1,'my_namespace']]]
];
