var structasio_1_1detail_1_1no__set__value__member =
[
    [ "ASIO_STATIC_CONSTEXPR", "d0/d11/structasio_1_1detail_1_1no__set__value__member.html#aaab2c3562dedcf3142066018970684b1", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d11/structasio_1_1detail_1_1no__set__value__member.html#a9d50996dca747093d61faaca2502275a", null ]
];