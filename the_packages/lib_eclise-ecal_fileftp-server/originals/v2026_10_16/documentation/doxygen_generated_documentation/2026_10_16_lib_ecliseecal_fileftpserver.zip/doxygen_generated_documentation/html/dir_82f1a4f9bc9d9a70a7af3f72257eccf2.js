var dir_82f1a4f9bc9d9a70a7af3f72257eccf2 =
[
    [ "connect_pair.cpp", "d5/d41/examples_2cpp11_2local_2connect__pair_8cpp.html", null ],
    [ "fd_passing_stream_client.cpp", "dd/dc3/fd__passing__stream__client_8cpp.html", null ],
    [ "fd_passing_stream_server.cpp", "d4/d22/fd__passing__stream__server_8cpp.html", null ],
    [ "iostream_client.cpp", "dd/d41/cpp11_2local_2iostream__client_8cpp.html", null ],
    [ "stream_client.cpp", "da/d52/cpp11_2local_2stream__client_8cpp.html", null ],
    [ "stream_server.cpp", "db/dbf/cpp11_2local_2stream__server_8cpp.html", null ]
];