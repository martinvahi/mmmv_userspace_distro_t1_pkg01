var searchData=
[
  ['win32_5flean_5fand_5fmean_0',['WIN32_LEAN_AND_MEAN',['../dc/d83/win32_2file__man_8cpp.html#ac7bef5d85e3dcd73eef56ad39ffc84a9',1,'file_man.cpp']]]
];
