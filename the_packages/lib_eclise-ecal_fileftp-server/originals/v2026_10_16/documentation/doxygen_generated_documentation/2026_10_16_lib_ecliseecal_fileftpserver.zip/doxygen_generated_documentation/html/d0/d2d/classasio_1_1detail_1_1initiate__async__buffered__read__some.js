var classasio_1_1detail_1_1initiate__async__buffered__read__some =
[
    [ "executor_type", "d0/d2d/classasio_1_1detail_1_1initiate__async__buffered__read__some.html#a813c52e86b186c75f19ea18bd481b1eb", null ],
    [ "initiate_async_buffered_read_some", "d0/d2d/classasio_1_1detail_1_1initiate__async__buffered__read__some.html#aae02191c76b008119a1bb0cb4b15af9f", null ],
    [ "get_executor", "d0/d2d/classasio_1_1detail_1_1initiate__async__buffered__read__some.html#a35b03a6341d79df877399d181311b5cb", null ],
    [ "operator()", "d0/d2d/classasio_1_1detail_1_1initiate__async__buffered__read__some.html#aaa683adbf509cdb0e9d70ae6a36c9d4a", null ]
];