var classasio_1_1error_1_1detail_1_1netdb__category =
[
    [ "message", "d0/d00/classasio_1_1error_1_1detail_1_1netdb__category.html#a6e51ee95977a8802ce85e54e1c506d1b", null ],
    [ "name", "d0/d00/classasio_1_1error_1_1detail_1_1netdb__category.html#a5d4e2ddd2dcb4a1c8eaff46244606dfc", null ]
];