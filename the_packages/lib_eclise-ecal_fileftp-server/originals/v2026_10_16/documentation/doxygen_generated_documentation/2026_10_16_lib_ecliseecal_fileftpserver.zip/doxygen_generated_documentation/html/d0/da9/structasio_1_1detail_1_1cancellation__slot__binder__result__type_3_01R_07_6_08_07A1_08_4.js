var structasio_1_1detail_1_1cancellation__slot__binder__result__type_3_01R_07_6_08_07A1_08_4 =
[
    [ "result_type", "d0/da9/structasio_1_1detail_1_1cancellation__slot__binder__result__type_3_01R_07_6_08_07A1_08_4.html#a26a1e1419c64c4e0ca015776e883de20", null ],
    [ "result_type_or_void", "d0/da9/structasio_1_1detail_1_1cancellation__slot__binder__result__type_3_01R_07_6_08_07A1_08_4.html#aa41f994daa1b92448bd3c8380cc4bcee", null ]
];