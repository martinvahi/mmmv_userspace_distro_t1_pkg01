var classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER =
[
    [ "func_type", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#af4da2ef0549c85267a4cf0908bbbc568", null ],
    [ "operation_type", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#ad530d2f209238f63fa0253a3cf1178bc", null ],
    [ "~scheduler_operation", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#aeb2648cfa9e1ea9fd1264019f31d38df", null ],
    [ "complete", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#a994602c7ef38a5dca06641718f6eaa5b", null ],
    [ "destroy", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#a7384f192052e719cb1f0db1a7727ae36", null ],
    [ "scheduler_operation", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#af47145a4fb99877365659cef626974ba", null ],
    [ "op_queue_access", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#a8e30c53833cb03dcfc31f84f66cd71c7", null ],
    [ "scheduler", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#a9dd9637c2a7c64b8b482570cd90169f7", null ],
    [ "task_result_", "d0/d4a/classasio_1_1detail_1_1ASIO__INHERIT__TRACKED__HANDLER.html#ace541f4b74231dfbec980267b7639108", null ]
];