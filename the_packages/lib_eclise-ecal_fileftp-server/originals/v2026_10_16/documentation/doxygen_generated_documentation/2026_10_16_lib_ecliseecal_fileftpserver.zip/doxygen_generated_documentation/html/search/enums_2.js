var searchData=
[
  ['cancellation_5ftype_5ft_0',['cancellation_type_t',['../db/dc3/namespaceasio_1_1cancellation__type.html#a5504f221489b790146180a643271a451',1,'asio::cancellation_type']]],
  ['channel_5ferrors_1',['channel_errors',['../d4/d42/namespaceasio_1_1experimental_1_1error.html#a8fa1047ebd0d8634fcbd581a9da620a5',1,'asio::experimental::error']]],
  ['charformat_2',['CharFormat',['../d0/da7/namespacetesting_1_1internal.html#ae2ef98247c76a50cdc80ceb4a6c81793',1,'testing::internal']]],
  ['command_5ftype_3',['command_type',['../d2/de6/classsocks4_1_1request.html#acf95348fed970fe2486702baba5877b4',1,'socks4::request::command_type'],['../d2/de6/classsocks4_1_1request.html#acf95348fed970fe2486702baba5877b4',1,'socks4::request::command_type']]]
];
