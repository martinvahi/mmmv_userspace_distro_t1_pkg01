var classasio_1_1detail_1_1awaitable__async__op__handler_3_01R_07T_08_00_01Executor_01_4 =
[
    [ "result_type", "d0/d72/classasio_1_1detail_1_1awaitable__async__op__handler_3_01R_07T_08_00_01Executor_01_4.html#ad13cec1b991569365e5e8435e6700160", null ],
    [ "awaitable_async_op_handler", "d0/d72/classasio_1_1detail_1_1awaitable__async__op__handler_3_01R_07T_08_00_01Executor_01_4.html#a2d1eae33800582d1a47d2cf25c7ab347", null ],
    [ "operator()", "d0/d72/classasio_1_1detail_1_1awaitable__async__op__handler_3_01R_07T_08_00_01Executor_01_4.html#a11eb7e166ff5a725a115da87078fd246", null ],
    [ "resume", "d0/d72/classasio_1_1detail_1_1awaitable__async__op__handler_3_01R_07T_08_00_01Executor_01_4.html#a57580f6372b86525db932c0017bb6740", null ]
];