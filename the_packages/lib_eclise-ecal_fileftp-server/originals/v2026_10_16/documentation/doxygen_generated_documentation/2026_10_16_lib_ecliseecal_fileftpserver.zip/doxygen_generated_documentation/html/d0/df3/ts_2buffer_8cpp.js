var ts_2buffer_8cpp =
[
    [ "BOOST_ALL_NO_LIB", "d0/df3/ts_2buffer_8cpp.html#a5ebdbdce56348e79bc296dba8e572a1f", null ],
    [ "BOOST_SYSTEM_NO_DEPRECATED", "d0/df3/ts_2buffer_8cpp.html#af801caa0803ded257cb30000090aa864", null ]
];