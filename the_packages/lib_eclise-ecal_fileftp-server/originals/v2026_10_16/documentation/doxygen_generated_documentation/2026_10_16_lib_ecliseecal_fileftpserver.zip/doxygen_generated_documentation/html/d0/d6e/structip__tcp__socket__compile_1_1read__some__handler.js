var structip__tcp__socket__compile_1_1read__some__handler =
[
    [ "read_some_handler", "d0/d6e/structip__tcp__socket__compile_1_1read__some__handler.html#ad289f1c4f9734311b1ef173083ddedcb", null ],
    [ "operator()", "d0/d6e/structip__tcp__socket__compile_1_1read__some__handler.html#abf1b072050c41a2900bbdb4a9f59b916", null ]
];