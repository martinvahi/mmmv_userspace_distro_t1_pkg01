var ip_2basic__endpoint_8hpp =
[
    [ "asio::ip::basic_endpoint&lt; InternetProtocol &gt;", "dc/db7/classasio_1_1ip_1_1basic__endpoint.html", "dc/db7/classasio_1_1ip_1_1basic__endpoint" ],
    [ "asio::ip::port_type", "d9/d3c/namespaceasio_1_1ip.html#a7aa31af3b1f4570451bb0a269302a3fa", null ]
];