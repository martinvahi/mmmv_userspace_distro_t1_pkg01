var classTypedTestNames =
[
    [ "GetName", "d0/de4/classTypedTestNames.html#af76babb242eca31c257de2f0b74973c1", null ],
    [ "GetName", "d0/de4/classTypedTestNames.html#af76babb242eca31c257de2f0b74973c1", null ]
];