var searchData=
[
  ['2_3a_20integrate_20as_20source_0',['Option 2: Integrate as source',['../dir_6a35cfd0f7be8a21012f81c494c374ef.html#autotoc_md8',1,'']]]
];
