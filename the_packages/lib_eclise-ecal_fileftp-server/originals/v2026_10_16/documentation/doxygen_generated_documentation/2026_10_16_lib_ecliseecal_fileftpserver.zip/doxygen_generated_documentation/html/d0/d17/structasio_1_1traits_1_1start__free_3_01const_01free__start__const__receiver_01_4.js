var structasio_1_1traits_1_1start__free_3_01const_01free__start__const__receiver_01_4 =
[
    [ "result_type", "d0/d17/structasio_1_1traits_1_1start__free_3_01const_01free__start__const__receiver_01_4.html#aa2e63f363e76d8800867730b8d5b5d57", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d17/structasio_1_1traits_1_1start__free_3_01const_01free__start__const__receiver_01_4.html#a7dc3b6bc8715f52f6a0b8261c4102d6d", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d17/structasio_1_1traits_1_1start__free_3_01const_01free__start__const__receiver_01_4.html#ae048f228b04b826b1119228a6bf9dd03", null ]
];