var classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d =
[
    [ "cancellation_slot_type", "d5/dcb/classasio_1_1detail_1_1base__from__cancellation__state.html#a19bc22d7feba7c1dc051a1a71953fac6", null ],
    [ "base_from_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#aa62f9ee4fc5127d5de1c073bae4336fe", null ],
    [ "base_from_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#afe1e88e85c163128ecce9042a228e921", null ],
    [ "base_from_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#a12c65ed7ab647f39874e5577620cea3c", null ],
    [ "cancelled", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#a1caf83bcc95ec60f9da76f0ffa592c7a", null ],
    [ "get_cancellation_slot", "d5/dcb/classasio_1_1detail_1_1base__from__cancellation__state.html#a09b4fe1dc3c7e8c13d52c0512ca0b5e4", null ],
    [ "get_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#aea1d9a59e834fcccb690888838db1473", null ],
    [ "reset_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#a48d82c7fd1d8cfb97b1825cd493bcbbb", null ],
    [ "reset_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#adf438ca4e275103193d3155182ec8e7e", null ],
    [ "reset_cancellation_state", "d0/d7a/classasio_1_1detail_1_1base__from__cancellation__state_3_01Handler_00_01typename_01enable__if_3_c45661ac7ab0f8bd96f7f93fae165e9d.html#a89ae9d1fd4c1107df3bfbd569290826c", null ]
];