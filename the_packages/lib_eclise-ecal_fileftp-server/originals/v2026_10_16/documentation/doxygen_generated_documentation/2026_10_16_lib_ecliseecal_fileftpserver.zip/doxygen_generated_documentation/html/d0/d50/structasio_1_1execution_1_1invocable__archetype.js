var structasio_1_1execution_1_1invocable__archetype =
[
    [ "result_type", "d0/d50/structasio_1_1execution_1_1invocable__archetype.html#a890bfcf90462fb73c2bb3ecf89daac26", null ],
    [ "operator()", "d0/d50/structasio_1_1execution_1_1invocable__archetype.html#a8cc09eb7e64dd0cff33f6180fa3c2bf2", null ]
];