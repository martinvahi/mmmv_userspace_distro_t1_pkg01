var scoped__lock_8hpp =
[
    [ "asio::detail::scoped_lock&lt; Mutex &gt;", "dc/d4f/classasio_1_1detail_1_1scoped__lock.html", "dc/d4f/classasio_1_1detail_1_1scoped__lock" ]
];