var classanonymous__namespace_02gtest__unittest_8cc_03_1_1ScopedFakeTestPartResultReporterTest =
[
    [ "FailureMode", "d0/d5a/classanonymous__namespace_02gtest__unittest_8cc_03_1_1ScopedFakeTestPartResultReporterTest.html#a5adda79327d956391d03135d0b7fc54e", [
      [ "FATAL_FAILURE", "d0/d5a/classanonymous__namespace_02gtest__unittest_8cc_03_1_1ScopedFakeTestPartResultReporterTest.html#a5adda79327d956391d03135d0b7fc54eaf3294eabb93f5cab41253656849dd4f9", null ],
      [ "NONFATAL_FAILURE", "d0/d5a/classanonymous__namespace_02gtest__unittest_8cc_03_1_1ScopedFakeTestPartResultReporterTest.html#a5adda79327d956391d03135d0b7fc54ea37428c68c83b44d822f02decdc839ba4", null ]
    ] ],
    [ "AddFailure", "d0/d5a/classanonymous__namespace_02gtest__unittest_8cc_03_1_1ScopedFakeTestPartResultReporterTest.html#ac0a7600982d6cb3c4b5a29ee6f7989ea", null ]
];