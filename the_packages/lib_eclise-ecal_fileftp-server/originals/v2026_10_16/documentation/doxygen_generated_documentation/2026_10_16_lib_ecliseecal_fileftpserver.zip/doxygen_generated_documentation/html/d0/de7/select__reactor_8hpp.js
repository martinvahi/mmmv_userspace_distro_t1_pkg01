var select__reactor_8hpp =
[
    [ "asio::detail::select_reactor", "d0/db9/classasio_1_1detail_1_1select__reactor.html", "d0/db9/classasio_1_1detail_1_1select__reactor" ],
    [ "asio::detail::select_reactor::per_descriptor_data", "d0/db9/classasio_1_1detail_1_1select__reactor.html#d8/de3/structasio_1_1detail_1_1select__reactor_1_1per__descriptor__data", null ]
];