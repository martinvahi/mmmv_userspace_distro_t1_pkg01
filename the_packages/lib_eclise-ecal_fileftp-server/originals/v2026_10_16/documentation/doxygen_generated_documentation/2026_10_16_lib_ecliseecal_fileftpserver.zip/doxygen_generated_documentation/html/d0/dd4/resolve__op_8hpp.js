var resolve__op_8hpp =
[
    [ "asio::detail::resolve_op", "d6/d1c/classasio_1_1detail_1_1resolve__op.html", "d6/d1c/classasio_1_1detail_1_1resolve__op" ]
];