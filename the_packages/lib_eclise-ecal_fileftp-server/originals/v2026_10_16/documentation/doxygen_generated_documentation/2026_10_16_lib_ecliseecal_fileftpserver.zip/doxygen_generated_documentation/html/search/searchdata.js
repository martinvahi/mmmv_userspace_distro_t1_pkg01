var indexSectionsWithContent =
{
  0: "0128:_abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijklmnopqrstuvwxy",
  2: "abcfghilmnprstw",
  3: "abcdefghiklmnopqrstuvwy",
  4: "_abcdefghijklmnopqrstuvwxyz~",
  5: "_abcdefghiklmnopqrstuvwxyz",
  6: "abcdefghijklmnopqrstuvwy",
  7: "abcdefghlmnoprstvw",
  8: "abcdefghiklmnoprstuvw",
  9: ":abcdefghimopqrstuw",
  10: "abefghijlmnoprstvwy",
  11: "acfo",
  12: "0128abcdefghijklmnopqrstuvwxy",
  13: "cde"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups",
  12: "pages",
  13: "concepts"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Modules",
  12: "Pages",
  13: "Concepts"
};

