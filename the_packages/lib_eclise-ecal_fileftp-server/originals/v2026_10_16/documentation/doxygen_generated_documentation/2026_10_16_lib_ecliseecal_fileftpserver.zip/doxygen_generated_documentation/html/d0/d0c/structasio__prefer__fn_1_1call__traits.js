var structasio__prefer__fn_1_1call__traits =
[
    [ "result_type", "d0/d0c/structasio__prefer__fn_1_1call__traits.html#a3057e533086368f1829c428a1c1b200a", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d0c/structasio__prefer__fn_1_1call__traits.html#ad3340796d7e0ab9c62482c26d355850a", null ],
    [ "ASIO_STATIC_CONSTEXPR", "d0/d0c/structasio__prefer__fn_1_1call__traits.html#a6f52972a70254d0d93ddabf74d476458", null ]
];