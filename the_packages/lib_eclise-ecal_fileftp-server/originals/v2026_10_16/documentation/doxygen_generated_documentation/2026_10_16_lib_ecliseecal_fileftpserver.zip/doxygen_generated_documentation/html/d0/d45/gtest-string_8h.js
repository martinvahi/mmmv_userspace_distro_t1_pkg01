var gtest_string_8h =
[
    [ "testing::internal::String", "d2/df8/classtesting_1_1internal_1_1String.html", "d2/df8/classtesting_1_1internal_1_1String" ],
    [ "testing::internal::StringStreamToString", "d0/da7/namespacetesting_1_1internal.html#ac0a2b7f69fc829d80a39e925b6417e39", null ]
];