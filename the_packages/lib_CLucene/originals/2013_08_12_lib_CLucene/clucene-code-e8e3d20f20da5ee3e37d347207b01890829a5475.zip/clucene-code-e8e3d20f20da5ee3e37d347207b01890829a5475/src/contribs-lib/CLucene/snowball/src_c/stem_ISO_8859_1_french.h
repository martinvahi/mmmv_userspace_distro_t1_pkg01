
/* This file was generated automatically by the Snowball to ANSI C compiler */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * french_ISO_8859_1_create_env(void);
extern void french_ISO_8859_1_close_env(struct SN_env * z);

extern int french_ISO_8859_1_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif

