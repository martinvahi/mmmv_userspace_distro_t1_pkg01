# Contributions

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in current work by you, as defined in the [Apache License (Version 2.0)](https://github.com/static-web-server/static-web-server/blob/master/LICENSE-APACHE) license, shall be dual licensed as described below, without any additional terms or conditions.

Feel free to send some [Pull request](https://github.com/static-web-server/static-web-server/pulls) or file an [issue](https://github.com/static-web-server/static-web-server/issues).

Or for feedback or questions feel free to reach us on [the discussions page](https://github.com/static-web-server/static-web-server/discussions).
