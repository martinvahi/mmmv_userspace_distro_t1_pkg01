# Build or improve documentation

To build or improve the documentation follow the [building documentation from source](https://static-web-server.net/building-from-source/#building-documentation-from-source) instructions.
