(() => console.log("Static Web Server running!"))()
