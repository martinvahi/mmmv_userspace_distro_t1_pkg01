# License

This work is primarily distributed under the terms of both the [MIT license](https://github.com/static-web-server/static-web-server/blob/master/LICENSE-MIT) and the [Apache License (Version 2.0)](https://github.com/static-web-server/static-web-server/blob/master/LICENSE-APACHE).

© 2019-present [Jose Quintana](https://github.com/joseluisq)

For feedback or questions feel free to reach us on [the discussions page](https://github.com/static-web-server/static-web-server/discussions).
