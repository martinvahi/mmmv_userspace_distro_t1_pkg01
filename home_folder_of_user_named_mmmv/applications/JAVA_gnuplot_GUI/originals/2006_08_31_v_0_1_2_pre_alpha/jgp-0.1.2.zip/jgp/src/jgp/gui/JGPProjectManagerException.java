package jgp.gui;

public class JGPProjectManagerException extends Exception {

	public JGPProjectManagerException() {
		// TODO Auto-generated constructor stub
	}

	public JGPProjectManagerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public JGPProjectManagerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public JGPProjectManagerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
