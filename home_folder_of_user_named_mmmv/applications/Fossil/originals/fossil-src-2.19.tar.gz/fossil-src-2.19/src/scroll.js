/* Cause the page to scroll so that the #scrollToMe is visible */
(document.getElementById('scrollToMe')||document.body).scrollIntoView(true);
