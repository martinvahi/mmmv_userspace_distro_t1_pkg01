# Contact Information

## Questions, Suggestions, and Bug Reports

The developers for Fossil monitor the [Fossil Forum][1].  Post there
with questions, improvement suggestions, and/or bug reports.

[1]: https://fossil-scm.org/forum/forum

## Security Problems and Vulnerabilities

If you think you have discovered a security vulnerability in Fossil
and want to report the problem privately, send
email to "drh&nbsp;at&nbsp;sqlite&nbsp;dot&nbsp;org".
