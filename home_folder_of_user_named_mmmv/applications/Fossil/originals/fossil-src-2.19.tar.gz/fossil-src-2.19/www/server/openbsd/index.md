# Debian/Ubuntu Specific Fossil Service Options

- [Serving Fossil under OpenBSD’s `httpd` via FastCGI](./fastcgi.md)
- [Running Fossil as a service on OpenBSD](./service.wiki)

*[Return to the top-level Fossil server article.](../)*
