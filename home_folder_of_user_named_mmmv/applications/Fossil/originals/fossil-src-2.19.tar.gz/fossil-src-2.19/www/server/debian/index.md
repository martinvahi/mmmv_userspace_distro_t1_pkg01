# Debian/Ubuntu Specific Fossil Service Options

- [SCGI under nginx](./nginx.md)
- [`systemd`](./service.md)

*[Return to the top-level Fossil server article.](../)*
