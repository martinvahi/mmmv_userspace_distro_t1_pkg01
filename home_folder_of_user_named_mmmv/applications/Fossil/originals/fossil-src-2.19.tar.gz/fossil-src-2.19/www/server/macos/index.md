# macOS Specific Fossil Service Options

- [Running Fossil under `launchd`](./service.md)

*[Return to the top-level Fossil server article.](../)*
