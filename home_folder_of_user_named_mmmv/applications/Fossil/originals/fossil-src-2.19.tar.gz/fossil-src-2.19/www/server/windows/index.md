# Using Windows as a Fossil Server

- [Fossil server command](./none.md)
- [Fossil as CGI (IIS)](./iis.md)
- [Fossil as a Service](./service.md)
- [Using stunnel with Fossil on Windows](./stunnel.md)

*[Return to the top-level Fossil server article.](../)*
