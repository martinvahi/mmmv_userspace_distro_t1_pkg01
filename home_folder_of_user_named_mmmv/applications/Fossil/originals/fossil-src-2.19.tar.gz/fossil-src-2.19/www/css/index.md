Cascading Style Sheet Notes
===========================

This is a collection of technical notes that document the design of
the Document Object Model (DOM) and corresponding Cascading Style Sheet (CSS)
attributes used for customing the look-and-feel of Fossil.  These notes
are of interest to people who want to customize the Fossil skin or
enhance the internal display logic.

This is a collection of documents that we hope will grow over time.

  *  [Diff styling](./diff.md)
