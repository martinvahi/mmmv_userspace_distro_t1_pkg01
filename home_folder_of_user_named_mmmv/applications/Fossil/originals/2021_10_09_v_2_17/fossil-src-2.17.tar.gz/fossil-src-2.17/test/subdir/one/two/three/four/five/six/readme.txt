This file exists in order to provide Fossil with a test case of a file
that is deeply nested below many subdirectories.
