#!/usr/bin/env bash 
# Initial author: Martin.Vahi@softf1.com
# This file is in public domain.
# Included files, written in Bash and Ruby, are under the MIT license.
#==========================================================================

I_NUMBER_OF_BACKUP_VERSIONS=3  # Please update to comply with Your wishes.
S_FP_FULL_PATH_2_A_FOLDER_OR_A_FILE_THAT_WILL_BE_BACKED_UP="$HOME/important_foo"

#--------------------------------------------------------------------------
source `pwd`/bonnet/engine_part_1.bash 
#==========================================================================

