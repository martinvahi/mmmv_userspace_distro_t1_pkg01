## exa › development tools

These scripts deal with things like packaging release-worthy versions of exa.

They are **not general-purpose scripts** that you’re able to run from your main computer! They’re intended to be run from the Vagrant machine.
