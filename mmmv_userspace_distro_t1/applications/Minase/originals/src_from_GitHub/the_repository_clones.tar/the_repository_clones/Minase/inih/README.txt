Original: https://github.com/benhoyt/inih
