Original: https://github.com/Tessil/robin-map
