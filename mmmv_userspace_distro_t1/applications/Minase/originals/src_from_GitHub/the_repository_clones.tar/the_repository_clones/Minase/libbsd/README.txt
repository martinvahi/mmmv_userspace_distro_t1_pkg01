Original: https://github.com/LuaDist/libbsd
