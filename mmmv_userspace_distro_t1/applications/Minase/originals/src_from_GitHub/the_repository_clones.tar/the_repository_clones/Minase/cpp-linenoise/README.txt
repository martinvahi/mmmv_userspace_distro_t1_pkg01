Original: https://github.com/yhirose/cpp-linenoise

Modified:
line 2324 comment out
line 2249 Add Arrowkey Code
Add default text
Add clear history
